/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.idpa;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Romain
 */
public class ViewController implements Initializable {

    @FXML
    private ComboBox<String> fromCurrency;
    @FXML
    private ComboBox<String> toCurrency;
    @FXML
    private TextField amount;
    @FXML
    private Label displayFromCurrency;
    @FXML
    private Button calculate;
    private Label calculatedAmount;
    @FXML
    private Label exchangeRateTargetCurrency;
    @FXML
    private Label calculatedOriginCurrency;
    @FXML
    private Label exchangeRateCHF;
    @FXML
    private Label calculatedCHF;
    @FXML
    private Label calculatedTargetCurrency;
    /**
     * Initializes the controller class.
     */
    Model m = new Model();

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
        String a = m.getReq_result();

        System.out.print(a);

        exchangeRateCHF.setText(a);

        ObservableList<String> optionsfromCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD", "JPY", "GBP", "CAD"
                );
        fromCurrency.setItems(optionsfromCurrency);

        ObservableList<String> optionstoCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD", "JPY", "GBP", "CAD"
                );
        toCurrency.setItems(optionstoCurrency);
    }
    //Method to round

    public static double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public void calculate() {
        try {
            DecimalFormat roundFormat = new DecimalFormat("#.##");
            Double result;
            Double roundResult;
            int roundTo = 3;
            Double numberAmount = Double.parseDouble(amount.getText());
            calculatedOriginCurrency.setText(numberAmount.toString() + " " + fromCurrency.getValue());
            //calculate to CHF
            if (fromCurrency.getValue().equals("CHF")) {
                roundResult = round(numberAmount, roundTo);
                calculatedCHF.setText(roundResult.toString() + " CHF");
            } else {
                m.ok(fromCurrency.getValue(), "CHF");
                result = Double.parseDouble(m.getReq_result()) * numberAmount;
                roundResult = round(result, roundTo);
                calculatedCHF.setText(roundResult.toString() + " CHF");
            }

            //calculate to target-currency
            m.ok(fromCurrency.getValue(), toCurrency.getValue());
            result = Double.parseDouble(m.getReq_result()) * numberAmount;
            exchangeRateTargetCurrency.setText(m.getReq_result());
            roundResult = round(result, roundTo);
            calculatedTargetCurrency.setText(roundResult.toString() + " " + toCurrency.getValue());
        } catch (Exception e) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Warning Dialog");

            alert.setContentText("'" + amount.getText() + "' ist kein gültiger Betrag.");

            alert.showAndWait();
        }
    }

    private void umrechnen(ActionEvent event) {
        if (fromCurrency.getValue() == "CHF" && toCurrency.getValue() == "EUR") {
            Double Wert = Double.parseDouble(amount.getText());
            double Werte = Wert * m.getUSD();
            String kursgerechneterWert = Double.toString(Werte);
            System.out.println(kursgerechneterWert);
            calculatedCHF.setText("Resultat: " + kursgerechneterWert);
        }
    }

}
