package ch.bbbaden.idpa;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 *
 * @author Romain
 */
public class Model {

    private String url_str;
    private String req_result;

    public String getReq_result() {
        return req_result;
    }

    public void requestCourse(String from, String to) {

        //CHF to anything
        if (from.equals("CHF") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/EUR";
        }
        if (from.equals("CHF") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/USD";
        }
        if (from.equals("CHF") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/AUD";
        }
        if (from.equals("CHF") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/JPY";
        }
        if (from.equals("CHF") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/GBP";
        }
        if (from.equals("CHF") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CHF/CAD";
        }

        //USD to anything
        if (from.equals("USD") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/EUR";
        }
        if (from.equals("USD") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/CHF";
        }
        if (from.equals("USD") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/AUD";
        }
        if (from.equals("USD") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/JPY";
        }
        if (from.equals("USD") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/GBP";
        }
        if (from.equals("USD") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/USD/CAD";
        }

        // EUR to *
        if (from.equals("EUR") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/CHF";
        }
        if (from.equals("EUR") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/USD";
        }
        if (from.equals("EUR") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/AUD";
        }
        if (from.equals("EUR") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/JPY";
        }
        if (from.equals("EUR") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/GBP";
        }
        if (from.equals("EUR") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/EUR/CAD";
        }

        // AUD to *
        if (from.equals("AUD") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/CHF";
        }
        if (from.equals("AUD") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/EUR";
        }
        if (from.equals("AUD") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/USD";
        }
        if (from.equals("AUD") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/JPY";
        }
        if (from.equals("AUD") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/GBP";
        }
        if (from.equals("AUD") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/AUD/CAD";
        }
        // JPY to *
        if (from.equals("JPY") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/CHF";
        }
        if (from.equals("JPY") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/EUR";
        }
        if (from.equals("JPY") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/USD";
        }
        if (from.equals("JPY") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/AUD";
        }
        if (from.equals("JPY") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/GBP";
        }
        if (from.equals("JPY") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/JPY/CAD";
        }
        // GBP to *
        if (from.equals("GBP") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/CHF";
        }
        if (from.equals("GBP") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/EUR";
        }
        if (from.equals("GBP") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/USD";
        }

        if (from.equals("GBP") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/AUD";
        }

        if (from.equals("GBP") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/JPY";
        }

        if (from.equals("GBP") && to.equals("CAD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/GBP/CAD";
        }
        // CAD to *
        if (from.equals("CAD") && to.equals("CHF")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/CHF";
        }
        if (from.equals("CAD") && to.equals("EUR")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/EUR";
        }
        if (from.equals("CAD") && to.equals("USD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/USD";
        }
        if (from.equals("CAD") && to.equals("AUD")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/AUD";
        }
        if (from.equals("CAD") && to.equals("JPY")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/JPY";
        }
        if (from.equals("CAD") && to.equals("GBP")) {
            url_str = "https://v6.exchangerate-api.com/v6/bc0992e1cc805c59c179f45b/pair/CAD/GBP";
        }

        try {

// Making Request
            URL url = new URL(url_str);
            HttpURLConnection request = (HttpURLConnection) url.openConnection();

            request.connect();

// Convert to JSON
            JsonParser jp = new JsonParser();
            JsonElement root = jp.parse(new InputStreamReader((InputStream) request.getContent()));
            JsonObject jsonobj = root.getAsJsonObject();

// Accessing object
            req_result = jsonobj.get("conversion_rate").getAsString();

        } catch (JsonIOException | JsonSyntaxException | IOException e) {
        }
    }
}
