/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.idpa;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Romain
 */
public class ViewController implements Initializable {
    
    @FXML
    private ComboBox<String> fromCurrency;
    @FXML
    private ComboBox<String> toCurrency;
    @FXML
    private TextField amount;
    @FXML
    private Label displayFromCurrency;
    @FXML
    private Button calculate;
    @FXML
    private Label exchangeRateTargetCurrency;
    @FXML
    private Label calculatedOriginCurrency;
    @FXML
    private Label exchangeRateCHF;
    @FXML
    private Label calculatedCHF;
    @FXML
    private Label calculatedTargetCurrency;

    Model m = new Model();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
        ObservableList<String> optionsfromCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD", "JPY", "GBP", "CAD"
                );
        fromCurrency.setItems(optionsfromCurrency);
        
        ObservableList<String> optionstoCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD", "JPY", "GBP", "CAD"
                );
        toCurrency.setItems(optionstoCurrency);
    }
    //Method to round

    private static BigDecimal round(BigDecimal value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        
        value = value.setScale(places, RoundingMode.HALF_UP);
        return value;
    }
    
    public void calculate() {
        try {
            //Rounding setup
            BigDecimal result;
            BigDecimal roundResult;
            int roundTo = 3;
            BigDecimal numberAmount = BigDecimal.valueOf(Double.parseDouble(amount.getText()));
            roundResult = round(numberAmount, roundTo);
            calculatedOriginCurrency.setText(roundResult.toString() + " " + fromCurrency.getValue());

            //calculate to CHF
            if (fromCurrency.getValue().equals("CHF")) {
                exchangeRateCHF.setText("1.0");
                roundResult = round(numberAmount, roundTo);
                calculatedCHF.setText(roundResult.toString() + " CHF");
            } else {
                m.requestCourse(fromCurrency.getValue(), "CHF");
                exchangeRateCHF.setText(m.getReq_result());
                result = BigDecimal.valueOf(Double.parseDouble(m.getReq_result())).multiply(numberAmount);
                roundResult = round(result, roundTo);
                calculatedCHF.setText(roundResult.toString() + " CHF");
            }

            //calculate to target-currency
            m.requestCourse(fromCurrency.getValue(), toCurrency.getValue());
            result = BigDecimal.valueOf(Double.parseDouble(m.getReq_result())).multiply(numberAmount);
            exchangeRateTargetCurrency.setText(m.getReq_result());
            roundResult = round(result, roundTo);
            calculatedTargetCurrency.setText(roundResult.toString() + " " + toCurrency.getValue());
        } catch (Exception e) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            
            alert.setContentText("'" + amount.getText() + "' ist kein gültiger Betrag.");
            
            alert.showAndWait();
        }
    }
}
