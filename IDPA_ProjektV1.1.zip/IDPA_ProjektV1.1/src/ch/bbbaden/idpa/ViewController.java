/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.idpa;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Romain
 */
public class ViewController implements Initializable {

    @FXML
    private ComboBox<String> fromCurrency;
    @FXML
    private ComboBox<String> toCurrency;
    @FXML
    private TextField amount;
    @FXML
    private Label displayFromCurrency;
    @FXML
    private Button calculate;
    private Label calculatedAmount;
    @FXML
    private Label exchangeRateTargetCurrency;
    @FXML
    private Label calculatedOriginCurrency;
    @FXML
    private Label exchangeRateCHF;
    @FXML
    private Label calculatedCHF;
    @FXML
    private Label calculatedTargetCurrency;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        ObservableList<String> optionsfromCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD","JPY","GBP","CAD"
                );
        fromCurrency.setItems(optionsfromCurrency);
        
        ObservableList<String> optionstoCurrency
                = FXCollections.observableArrayList(
                        "CHF", "EUR", "USD", "AUD","JPY","GBP","CAD"
                );
        toCurrency.setItems(optionstoCurrency);
    }
    public void calculate() {
        try {
            double numberAmount = Double.parseDouble(amount.getText());
        } catch (Exception e) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            
            alert.setContentText("'"+amount.getText()+"' ist kein gültiger Betrag.");

            alert.showAndWait();
        }
    }


    private void umrechnen(ActionEvent event) {
            if (fromCurrency.getValue() == "CHF" && toCurrency.getValue() == "EUR") {
            Double Wert = Double.parseDouble(amount.getText());
            double Werte = Wert * Kurs;
            String kursgerechneterWert = Double.toString(Werte);
            System.out.println(kursgerechneterWert);
            calculatedCHF.setText("Resultat: " + kursgerechneterWert);
        }
    }



}
